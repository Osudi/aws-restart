firstString = "water"
secondString = "fail"
thirdString = firstString + secondString
print(thirdString)
name = input("what is your name?")
print(name)
color = input("what is your favorite color?")
animal = input("what is your favorite animal?")
print("{}, you like a {} {}!".format(name,color,animal))
myFruitlist= ["apple", "banana", "cherry"]
print(myFruits)
print(type(myFruitlist))